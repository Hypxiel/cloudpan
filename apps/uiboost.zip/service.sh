#!/system/bin/sh
MODDIR=${0%/*}

function boost() {
  pgrep -x "$1" | while read pid; do
    echo "$pid" > /dev/cpuset/top-app/cgroup.procs
  done
}
function slowdown() {
  pgrep -x "$1" | while read pid; do
    echo "$pid" > /dev/cpuset/foreground/cgroup.procs
  done
}
function is_top_app() {
  local pid
  pid=$(pgrep -x "$1" | head -1)
  if [ -z "$pid" ]; then
    return 1
  fi
  grep -qw "$pid" /dev/cpuset/top-app/cgroup.procs 2>/dev/null
}

#读取桌面包名
if [ -f "$MODDIR/desktop.txt" ]; then
  desktop=$(cat "$MODDIR/desktop.txt")
  echo "$(date +\"%H:%M:%S\") 桌面包名：$desktop" >> $MODDIR/debug.txt
else
  flag="false"
  echo "desktop.txt文件不存在，已停止运行" >> $MODDIR/debug.txt
  exit 1
fi

count=0
while true; do
if is_top_app $desktop; then
  # 已在 top-app，无需 boost
  sleep 3
  count=0
elif [ "$count" -gt 60 ]; then
  break
else
  # 不在 top-app，需要 boost
  # boost系统桌面
  boost $desktop
  # boost通知与状态栏
  #boost com.android.systemui
  #slowdown kswapd0
  sleep 1
  count=$((count + 1))
fi
done
echo "桌面包名不正确，已停止运行" >> $MODDIR/debug.txt
