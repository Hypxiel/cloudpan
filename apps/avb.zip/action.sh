#!/bin/sh
echo ""
echo ""
echo ""
echo ""
echo $(avbctl get-verity) | grep -q disabled
[ $? -eq 0 ] && status="已关闭" || status="已开启"
echo "当前AVB verity状态: $status" 
echo $(avbctl get-verification)| grep -q disabled
[ $? -eq 0 ] && status="已关闭" || status="已开启"
echo "当前AVB verification状态： $status" 



sleep 5
exit 0